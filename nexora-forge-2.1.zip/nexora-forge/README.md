# NEXORA Forge 2.1 — Local PC Starter + Desktop Voice Controls

A local-first AI workspace starter consolidating the user's requested NEXORA features: OpenAI-compatible AI chat, local endpoint checks/model discovery, FreeToken gateway configuration, server-side API keys, local file attachments, project scaffolding, and MCP configuration storage.

## Requirements
- Windows 10/11
- Python 3.11+ available as `py -3`
- Optional: FreeToken running separately on port 3000; any local AI services you want to use

## Run
1. Extract this folder to a normal writable location, e.g. `C:\NEXORA-Forge`.
2. Double-click `run.bat`.
3. Wait for the server, then open `http://127.0.0.1:8787` in your browser.
4. Stop it with Ctrl+C in the terminal window.
5. On first run, `.env.example` is copied to `.env`. Edit `.env` with Notepad and restart the server to use provider keys.

## Add FreeToken
Use the exact repository `https://github.com/V-Groups-Foundations/freetoken`.
1. Install Node.js 20.9+.
2. In PowerShell, run:
   ```powershell
   git clone https://github.com/V-Groups-Foundations/freetoken.git
   cd freetoken
   npm install
   npm run dev
   ```
3. Open `http://127.0.0.1:3000`, create an API token in its API page, and copy it only into NEXORA's local `.env` as `FREETOKEN_API_KEY=...`.
4. Keep `FREETOKEN_BASE_URL=http://127.0.0.1:3000/api/v1` unless FreeToken reports a different local port/base URL.
5. Restart NEXORA. In AI Workspace select FreeToken and use `auto-smart` or a model ID reported by its `/models` endpoint.

Review a cloned repository's package scripts before running dependencies. Do not paste API keys into chat, source code, frontend files or APKs.

## Local endpoints
- Ollama: `http://127.0.0.1:11434/v1`
- LM Studio: `http://127.0.0.1:1234/v1`
- llama.cpp: `http://127.0.0.1:8080/v1`
- vLLM: `http://127.0.0.1:8000/v1`
- LocalAI: `http://127.0.0.1:8081/v1` (change if needed)
- Jan: `http://127.0.0.1:1337/v1`
- LiteLLM: `http://127.0.0.1:4000/v1`

## Current limitations — do not mistake placeholders for completed integrations
- This starter sends chat to OpenAI-compatible `/chat/completions` endpoints. Some providers/models may require different model IDs or API formats.
- MCP entries are saved to `data/mcp-config.json`; this version does not launch arbitrary MCP processes or execute MCP tools.
- Uploads are saved locally; they are not automatically passed to a model or executed.
- Project Studio creates a basic web starter scaffold. It does not yet implement full AI multi-file editing, automated tests/repair, video generation, Android SDK builds or APK signing.
- LocalCodeCli is documented as an intended integration but is not installed or invoked by this starter.
- No Google OAuth, multi-user accounts, or remote/public access is enabled.

## Security
- The service binds to `127.0.0.1`, not the network interface.
- Keep `.env` private; `.gitignore` excludes it.
- Never expose port 8787 or FreeToken port 3000 to the public internet without authentication, TLS and appropriate access controls.
- FreeToken is a gateway, not a magic source of unlimited provider keys; quotas and free tiers are provider-controlled and may change.

## API & Crypto Catalog
Open **API Catalog** in the sidebar and click **Sync catalog data**. It fetches public Markdown tables from the fixed GitHub source list in `app.py`, including Free Crypto APIs, awesome-free-llm-apis, and FreeLLM-API-KeyHub. The GitHub `free-llm-api` topic is linked for repository discovery. The catalog stores normalized table facts locally in `data/catalog/catalog.json`; it never downloads or executes repository code. Provider quotas change often, so confirm current limits on official provider sites. No provider API keys are generated or bundled.

## NEXORA Forge 2.1 upgrade: desktop voice controls and expanded catalogs

This upgrade preserves the original provider chat, local endpoint checks, FreeToken settings, file uploads, project scaffolding and MCP configuration registry. It adds a searchable source catalog for datasets, public APIs, agent skills, MCP servers and local AI projects, plus a limited Windows desktop-control API and voice-command UI.

### Desktop controls
- `open Notepad`, `open Chrome`, `open Steam`, or a local `.exe` path
- `open website https://example.com`
- `type Hello world`
- `press Enter`, `press Ctrl+S`, `press Alt+Tab`
- `click 400 300` (screen coordinates)
- `stop, NEXORA` stops voice listening and sends Escape to the focused app

Voice recognition uses the browser's speech-recognition implementation and microphone permission. Commands are intentionally limited; arbitrary shell commands and destructive file operations are not exposed. Desktop actions work only when the server runs on Windows. Install optional automation packages with `setup_desktop.bat`.

### Build a single-file Windows executable
1. On Windows 10/11, install Python 3.11+ and enable its PATH option.
2. Extract this ZIP to a writable folder such as `C:\\NEXORA-Forge`.
3. Double-click `build_exe.bat` and wait for PyInstaller to finish.
4. Test `dist\\NEXORA-Forge.exe`. The build script is supplied but the EXE is not prebuilt or verified on this non-Windows build environment.
5. Keep `.env` beside the EXE. It stores your local configuration and secret API keys; never share it or include it in a public upload.

The desktop launcher opens a local web workspace in your default browser and provides a small launcher window for stopping the local server. The service binds to `127.0.0.1` only. Do not forward its port to the public internet.

### Expanded resource sources
The catalog includes `goerlitz/ai-datasets`, `awesomedata/awesome-public-datasets`, `public-apis/public-apis`, `philipbankier/awesome-agent-skills`, `anthropics/skills`, `modelcontextprotocol/servers`, `punkpeye/awesome-mcp-servers`, `ollama/ollama`, `ggml-org/llama.cpp`, `mudler/LocalAI`, `vllm-project/vllm`, and `BerriAI/litellm`, along with the previous free-LLM and crypto API sources. Use **Unified Resource Catalog → Sync catalog data** to fetch public README/list data. This does not download all underlying datasets, create provider API keys, or execute repository code. Check each repository's license and each linked dataset/API's own terms before use.

### Still not included as fully integrated features
- Full arbitrary desktop vision/GUI agent, game-playing agent, and unrestricted background microphone wake-word engine.
- Live MCP tool execution; this release still stores MCP configuration only.
- Complete AI multi-file editing/test-repair loop, video generation provider integration, Google OAuth, APK signing, or trading order execution.
- A prebuilt Windows EXE: build it locally with `build_exe.bat` and test it on the target PC.
