@echo off
setlocal
cd /d "%~dp0"
if not exist .venv (
  py -3 -m venv .venv
  if errorlevel 1 (echo Python 3.11+ is required. Install it from python.org and enable Add to PATH.& pause & exit /b 1)
)
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -r requirements.txt pyautogui pywinauto pyperclip
if not exist .env copy .env.example .env
echo.
echo Desktop dependencies installed. Use run.bat to start NEXORA.
pause
