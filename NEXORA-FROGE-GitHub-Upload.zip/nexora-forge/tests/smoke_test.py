"""Basic local smoke tests for NEXORA Forge API routes."""
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from fastapi.testclient import TestClient
from app import app, CATALOG_SOURCES, _parse_markdown_tables

client = TestClient(app)
for route in ("/", "/api/info", "/api/providers", "/api/catalog", "/api/desktop/status", "/api/projects", "/api/mcp"):
    response = client.get(route)
    assert response.status_code == 200, f"{route}: {response.status_code} {response.text[:200]}"

source_ids = {source["id"] for source in CATALOG_SOURCES}
for expected in ("ai-datasets", "awesome-public-datasets", "public-apis", "awesome-agent-skills", "mcp-servers", "ollama", "llama-cpp", "freetoken", "localcodecli", "openswissdata-mcp"):
    assert expected in source_ids, f"Missing catalog source: {expected}"

rows = _parse_markdown_tables("# Datasets\n- [Sample dataset](https://example.org/data) - public\n", {"id":"test","name":"Test","url":"https://github.com/example/repo","kind":"datasets"})
assert rows and rows[0]["data"]["name"] == "Sample dataset"
print("NEXORA Forge smoke tests passed.")
