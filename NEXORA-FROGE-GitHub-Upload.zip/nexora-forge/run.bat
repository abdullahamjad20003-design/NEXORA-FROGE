@echo off
setlocal
cd /d "%~dp0"
if not exist .venv (
  echo Creating Python virtual environment...
  py -3 -m venv .venv
  if errorlevel 1 (echo Python 3.11+ not found. Install Python 3.11+ and enable Add to PATH.& pause & exit /b 1)
)
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -r requirements.txt pyautogui pywinauto pyperclip
if not exist .env copy .env.example .env
start "NEXORA browser" cmd /c "timeout /t 3 /nobreak ^>nul ^& start http://127.0.0.1:8787"
echo NEXORA Forge will open at http://127.0.0.1:8787
echo Keep this window open while using the app. Stop with Ctrl+C.
python -m uvicorn app:app --host 127.0.0.1 --port 8787
pause
