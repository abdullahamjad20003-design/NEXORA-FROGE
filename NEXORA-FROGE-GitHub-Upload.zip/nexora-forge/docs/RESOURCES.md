# GitHub resources and integrations

These are upstream references for exploration, not bundled dependencies or endorsements. Check each repository's license, maintenance status, package scripts, and security posture before installing or executing anything. Dataset licenses and terms can vary per dataset.

## Datasets and public APIs

- AI datasets: <https://github.com/goerlitz/ai-datasets>
- Awesome public datasets: <https://github.com/awesomedata/awesome-public-datasets>
- Public APIs catalog: <https://github.com/public-apis/public-apis>
- General curated resources: <https://github.com/sindresorhus/awesome>

## LLM APIs and gateway

- FreeToken gateway: <https://github.com/V-Groups-Foundations/freetoken>
- Free crypto APIs: <https://github.com/narekgevorgyan/free-crypto-apis>
- Awesome free LLM APIs: <https://github.com/open-free-llm-api/awesome-freellm-apis>
- FreeLLM-API-KeyHub: <https://github.com/guihuashaoxiang/FreeLLM-API-KeyHub>
- GitHub topic: <https://github.com/topics/free-llm-api>

Do not rely on third-party lists for secrets. Never use a key published by an unknown person; it may be stolen, revoked, rate-limited, or maliciously monitored. Obtain credentials from official provider dashboards.

## Local AI runtimes and proxies

- Ollama: <https://github.com/ollama/ollama>
- llama.cpp: <https://github.com/ggml-org/llama.cpp>
- LocalAI: <https://github.com/mudler/LocalAI>
- vLLM: <https://github.com/vllm-project/vllm>
- LiteLLM: <https://github.com/BerriAI/litellm>
- LM Studio: <https://lmstudio.ai/>
- Jan: <https://jan.ai/>

## MCP servers and agent skills

- Model Context Protocol servers: <https://github.com/modelcontextprotocol/servers>
- Awesome MCP servers: <https://github.com/punkpeye/awesome-mcp-servers>
- Agent skills collection: <https://github.com/philipbankier/awesome-agent-skills>
- Anthropic skills examples: <https://github.com/anthropics/skills>
- LocalCodeCli reference: <https://github.com/Corporationakht/LocalCodeCli>

Review tools and permissions before enabling them. This NEXORA starter currently stores MCP configuration but does not launch arbitrary MCP servers or execute their tools.

## OpenSwissData

- MCP endpoint supplied for this project: <https://mcp.openswissdata.com/mcp/jsonrpc>
- Project reference: <https://github.com/openswissdata-assistant> (check availability and official setup docs before use)

The endpoint is a reference only; this starter does not currently provide a complete, authenticated OpenSwissData MCP execution integration.

## Provider official sites

- Google AI Studio / Gemini: <https://aistudio.google.com/>
- OpenRouter: <https://openrouter.ai/>
- Groq: <https://groq.com/>
- Mistral: <https://mistral.ai/>
- NVIDIA NIM: <https://build.nvidia.com/>
- Cerebras: <https://cloud.cerebras.ai/>
- Cohere: <https://cohere.com/>
- Hugging Face: <https://huggingface.co/>
