# Security notes

## Secrets and public repositories

- `.env` is for local secrets and must never be committed.
- `.env.example` must contain placeholders only, not real API keys, cookies, passwords, or private endpoints.
- Do not put secrets in `app.py`, JavaScript/HTML, README screenshots, issue reports, workflow logs, APKs, EXEs, or GitHub Actions files.
- Check staged changes before committing: `git status --short` and `git diff --cached`.
- If a secret is exposed, revoke/rotate it immediately at the issuing provider. Assume it has been copied; removing it from the latest commit is not enough.

## Local network exposure

The intended default is loopback-only access at `http://127.0.0.1:8787`. Do not change the host to `0.0.0.0` or forward the port from your router unless you have designed and tested authentication, TLS, authorization, request limits, and network restrictions.

## Uploads and generated code

Treat uploaded documents, AI outputs, shell commands, and third-party repositories as untrusted input. Do not automatically execute uploaded files. Review generated code before running it and use a disposable folder or virtual machine for untrusted projects.

## Desktop automation

Tools such as PyAutoGUI can control the keyboard and mouse. Keep a visible stop method, test with harmless actions, and require manual confirmation for deleting files, sending messages, purchases, account changes, financial actions, or other high-impact operations. Never use this app to access devices or accounts without authorization.

## Trading integrations

This starter is not a validated trading system and does not implement safe live execution. Any future trading integration should default to demo/testnet, use least-privilege API credentials, include explicit order confirmation and risk limits, and never store credentials in a public repository or mobile client.

## MCP and external tools

A saved MCP server configuration is not proof that the server is safe or that tools are being executed. Verify the server publisher, source, license, permissions, commands, environment variables, and network destinations before starting it. Use minimal permissions and avoid running unknown commands as administrator.
