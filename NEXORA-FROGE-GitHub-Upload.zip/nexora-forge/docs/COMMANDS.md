# Commands, setup, run and build

These instructions target Windows 10/11 and PowerShell unless stated otherwise.

## 1. Download the project

Using Git:

```powershell
git clone https://github.com/abdullahamjad20003-design/NEXORA-FROGE.git
cd NEXORA-FROGE
```

Or use **Code → Download ZIP** on GitHub and extract it. If the repository currently contains only documentation, download the source bundle supplied separately and copy its `nexora-forge` project files into your local clone. Do not overwrite an existing file without checking its contents first.

## 2. Check Python and Git

```powershell
py -3 --version
git --version
```

Install Python 3.11+ from <https://www.python.org/downloads/windows/> if `py` is unavailable. Install Git from <https://git-scm.com/download/win> if needed.

## 3. Run the app

Recommended beginner method: double-click `run.bat`.

Manual PowerShell method from the project root:

```powershell
py -3 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
pip install pyautogui pywinauto pyperclip
if (-not (Test-Path .env)) { Copy-Item .env.example .env }
python -m uvicorn app:app --host 127.0.0.1 --port 8787
```

Open <http://127.0.0.1:8787>. Keep the terminal open. Stop the service with `Ctrl+C`.

If PowerShell blocks virtual-environment activation, use `run.bat` instead or follow Microsoft's current PowerShell execution-policy guidance. Do not weaken system policy globally just to run this project.

## 4. Configure keys

Edit `.env` locally and restart the app. Do not commit `.env`:

```powershell
git status --short
```

Confirm `.env` and any uploaded files are not staged. If a key was committed or shared, revoke/rotate it at the provider immediately; deleting the latest file is not sufficient to erase it from Git history.

## 5. Run smoke checks

```powershell
.\.venv\Scripts\Activate.ps1
python tests\smoke_test.py
```

## 6. Build the Windows executable

On Windows, double-click `build_exe.bat`, or run:

```powershell
py -3 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt pyautogui pywinauto pyperclip pyinstaller
pyinstaller --noconfirm --clean --onefile --windowed --name NEXORA-Forge --add-data ".env.example;." --collect-all uvicorn --collect-all fastapi --collect-all starlette --collect-all pyautogui desktop_launcher.py
```

If the build succeeds, inspect `dist\NEXORA-Forge.exe`. Test on the target Windows PC. Do not claim the executable works until it has been launched and verified there. Keep `.env` private and do not package credentials into the EXE.

## 7. Git commands for contributing

```powershell
git status
git switch -c docs-or-feature-name
git add README.md docs/ tests/ app.py requirements.txt run.bat build_exe.bat desktop_launcher.py .env.example .gitignore
git diff --cached
git commit -m "Document and improve NEXORA Forge"
git push -u origin docs-or-feature-name
```

Only stage the files you intend to publish. Never use `git add .` blindly if your workspace may contain `.env`, uploads, keys, build outputs, or private files. Open a pull request after pushing the branch.

## Troubleshooting

- **`py` not found:** install Python 3.11+ and enable the Python launcher / PATH option.
- **Port 8787 already in use:** close the other NEXORA instance or identify the process using the port before stopping anything.
- **Provider returns 401/403:** check the provider key, account access, endpoint, and model ID.
- **Provider returns 429:** likely rate/quota limit; check provider dashboard and retry policy.
- **Local model missing:** start the local service, load/download a model, and verify its configured endpoint.
- **EXE build fails:** run the build commands in an open PowerShell window to capture the full error; update dependencies only after reviewing compatibility.
- **Windows Defender warning:** do not disable protection blindly. Inspect source, build locally, and investigate the detection before running the EXE.
