from __future__ import annotations
import os, json, secrets, mimetypes, re, time, sys, platform, shutil, subprocess, webbrowser, asyncio
from pathlib import Path
from html import escape as html_escape
from typing import Any
import httpx
from fastapi import FastAPI, HTTPException, UploadFile, File, Header
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from dotenv import load_dotenv

ROOT = Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parent
DATA = ROOT / "data"
UPLOADS = DATA / "uploads"
PROJECTS = DATA / "projects"
for p in (DATA, UPLOADS, PROJECTS): p.mkdir(parents=True, exist_ok=True)
load_dotenv(ROOT / ".env")

app = FastAPI(title="NEXORA Forge", version="2.1.0")
# Local-only service. Do not expose this app to a LAN/public interface without authentication.
app.add_middleware(CORSMiddleware, allow_origins=["http://127.0.0.1:8787", "http://localhost:8787"], allow_methods=["GET", "POST"], allow_headers=["*"])

LOCAL_PROVIDERS = {
    "Ollama": (os.getenv("OLLAMA_BASE_URL", "http://127.0.0.1:11434/v1"), os.getenv("OLLAMA_API_KEY", "ollama")),
    "LM Studio": (os.getenv("LMSTUDIO_BASE_URL", "http://127.0.0.1:1234/v1"), os.getenv("LMSTUDIO_API_KEY", "lm-studio")),
    "llama.cpp": (os.getenv("LLAMACPP_BASE_URL", "http://127.0.0.1:8080/v1"), os.getenv("LLAMACPP_API_KEY", "llama")),
    "vLLM": (os.getenv("VLLM_BASE_URL", "http://127.0.0.1:8000/v1"), os.getenv("VLLM_API_KEY", "vllm")),
    "LocalAI": (os.getenv("LOCALAI_BASE_URL", "http://127.0.0.1:8081/v1"), os.getenv("LOCALAI_API_KEY", "localai")),
    "Jan": (os.getenv("JAN_BASE_URL", "http://127.0.0.1:1337/v1"), os.getenv("JAN_API_KEY", "jan")),
    "LiteLLM": (os.getenv("LITELLM_BASE_URL", "http://127.0.0.1:4000/v1"), os.getenv("LITELLM_API_KEY", "")),
}
# Explicit HTTPS provider endpoints only. Keys remain on the backend in .env.
CLOUD_PROVIDERS = {
    "OpenRouter": ("https://openrouter.ai/api/v1", os.getenv("OPENROUTER_API_KEY", "")),
    "Groq": ("https://api.groq.com/openai/v1", os.getenv("GROQ_API_KEY", "")),
    "Gemini (OpenAI-compatible)": (os.getenv("GEMINI_OPENAI_BASE_URL", "https://generativelanguage.googleapis.com/v1beta/openai"), os.getenv("GEMINI_API_KEY", "")),
    "Mistral": ("https://api.mistral.ai/v1", os.getenv("MISTRAL_API_KEY", "")),
    "NVIDIA NIM": ("https://integrate.api.nvidia.com/v1", os.getenv("NVIDIA_API_KEY", "")),
    "Cerebras": ("https://api.cerebras.ai/v1", os.getenv("CEREBRAS_API_KEY", "")),
    "SambaNova": ("https://api.sambanova.ai/v1", os.getenv("SAMBANOVA_API_KEY", "")),
    "Cohere (OpenAI-compatible where enabled)": (os.getenv("COHERE_OPENAI_BASE_URL", "https://api.cohere.com/compatibility/v1"), os.getenv("COHERE_API_KEY", "")),
    "GitHub Models": ("https://models.inference.ai.azure.com", os.getenv("GITHUB_MODELS_API_KEY", "")),
    "Hugging Face (OpenAI-compatible endpoint)": (os.getenv("HUGGINGFACE_BASE_URL", "https://router.huggingface.co/v1"), os.getenv("HUGGINGFACE_API_KEY", "")),
}
FREE_TOKEN_URL = os.getenv("FREETOKEN_BASE_URL", "http://127.0.0.1:3000/api/v1").rstrip("/")
FREE_TOKEN_KEY = os.getenv("FREETOKEN_API_KEY", "")

class ChatRequest(BaseModel):
    provider: str = "FreeToken"
    model: str = "auto-smart"
    messages: list[dict[str, Any]]
    temperature: float = 0.4

class ProjectRequest(BaseModel):
    name: str
    description: str = ""
    kind: str = "web"

class McpConfig(BaseModel):
    name: str
    command: str = ""
    args: list[str] = Field(default_factory=list)
    url: str = ""

class DesktopCommand(BaseModel):
    action: str
    target: str = ""
    text: str = ""
    x: int | None = None
    y: int | None = None
    key: str = ""


def provider_config(name: str):
    if name == "FreeToken":
        return FREE_TOKEN_URL, FREE_TOKEN_KEY or ""
    if name in LOCAL_PROVIDERS: return LOCAL_PROVIDERS[name]
    if name in CLOUD_PROVIDERS: return CLOUD_PROVIDERS[name]
    raise HTTPException(400, "Unknown provider")

async def get_models(base: str, key: str):
    headers = {"Authorization": f"Bearer {key}"} if key else {}
    async with httpx.AsyncClient(timeout=5.0) as client:
        r = await client.get(base.rstrip("/") + "/models", headers=headers)
        r.raise_for_status()
        return r.json()

@app.get("/", response_class=HTMLResponse)
async def home():
    return HTML

@app.get("/api/status")
async def status():
    result = []
    providers = {"FreeToken": (FREE_TOKEN_URL, FREE_TOKEN_KEY), **LOCAL_PROVIDERS, **CLOUD_PROVIDERS}
    async with httpx.AsyncClient(timeout=0.9, follow_redirects=True) as client:
        async def probe(name: str, base: str, key: str):
            configured = bool(key) if name in CLOUD_PROVIDERS or name == "FreeToken" else True
            try:
                r = await client.get(base.rstrip("/") + "/models", headers={"Authorization": f"Bearer {key}"} if key else {})
                return {"name": name, "configured": configured, "online": r.is_success, "detail": "Connected" if r.is_success else f"HTTP {r.status_code}"}
            except Exception:
                return {"name": name, "configured": configured, "online": False, "detail": "Not reachable"}
        result = await asyncio.gather(*(probe(name, base, key) for name, (base, key) in providers.items()))
    return {"app": "NEXORA Forge 2.1", "providers": result, "freetoken_base_url": FREE_TOKEN_URL}

@app.get("/api/providers")
def providers():
    items = []
    for name in ["FreeToken", *LOCAL_PROVIDERS.keys(), *CLOUD_PROVIDERS.keys()]:
        base, key = provider_config(name)
        items.append({"name": name, "base_url": base, "configured": bool(key) if name == "FreeToken" or name in CLOUD_PROVIDERS else True})
    return {"providers": items}

@app.get("/api/models/{provider}")
async def models(provider: str):
    name = provider.replace("__", "/")
    base, key = provider_config(name)
    try: return await get_models(base, key)
    except Exception as e: raise HTTPException(502, f"Could not fetch models from {name}. Check service, URL and credentials in .env.")

@app.post("/api/chat")
async def chat(req: ChatRequest):
    base, key = provider_config(req.provider)
    if req.provider == "FreeToken" and not key:
        # FreeToken can run without a token only if its local instance permits it; normally create a token in its API page.
        raise HTTPException(400, "Set FREETOKEN_API_KEY in .env using a token generated by your local FreeToken instance, then restart NEXORA.")
    headers = {"Authorization": f"Bearer {key}"} if key else {}
    headers["Content-Type"] = "application/json"
    payload = {"model": req.model, "messages": req.messages, "temperature": max(0, min(1.5, req.temperature)), "stream": False}
    try:
        async with httpx.AsyncClient(timeout=120.0) as client:
            r = await client.post(base.rstrip("/") + "/chat/completions", headers=headers, json=payload)
            if not r.is_success:
                detail = r.text[:700]
                raise HTTPException(r.status_code if r.status_code < 500 else 502, f"Provider error: {detail}")
            return r.json()
    except HTTPException: raise
    except httpx.RequestError: raise HTTPException(502, f"Cannot reach {req.provider}. Confirm that it is running and the URL is correct.")

@app.post("/api/upload")
async def upload(file: UploadFile = File(...)):
    safe = Path(file.filename or "upload.bin").name.replace("..", "_")
    if not safe: safe = "upload.bin"
    dest = UPLOADS / (secrets.token_hex(5) + "_" + safe)
    data = await file.read(20 * 1024 * 1024 + 1)
    if len(data) > 20 * 1024 * 1024: raise HTTPException(413, "Maximum attachment size is 20 MB")
    dest.write_bytes(data)
    return {"filename": safe, "stored_as": dest.name, "bytes": len(data), "note": "Saved locally. Attachments are not automatically executed."}

@app.post("/api/projects")
def create_project(req: ProjectRequest):
    safe = "".join(c for c in req.name if c.isalnum() or c in "-_ ").strip().replace(" ", "-")[:60] or "new-project"
    folder = PROJECTS / safe
    folder.mkdir(parents=True, exist_ok=True)
    manifest = {"name": req.name, "description": req.description, "kind": req.kind, "created_by": "NEXORA Forge", "status": "scaffolded"}
    (folder / "nexora-project.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    if req.kind == "web":
        (folder / "index.html").write_text(f'''<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{html_escape(req.name)}</title><style>body{{font-family:system-ui;background:#101322;color:#f3f5ff;display:grid;place-items:center;min-height:100vh;margin:0}}main{{max-width:760px;padding:3rem}}h1{{font-size:clamp(2rem,7vw,4rem)}}p{{color:#b8bfd9}}</style></head><body><main><h1>{html_escape(req.name)}</h1><p>{html_escape(req.description)}</p><p>Starter project created by NEXORA Forge.</p></main></body></html>''', encoding="utf-8")
    return {"ok": True, "folder": str(folder), "files": [x.name for x in folder.iterdir()], "note": "This creates a starter scaffold, not a production app or APK by itself."}

@app.get("/api/projects")
def list_projects():
    return {"projects": [{"name": p.name, "files": [f.name for f in p.iterdir()]} for p in PROJECTS.iterdir() if p.is_dir()]}

@app.get("/api/mcp")
def get_mcp():
    path = DATA / "mcp-config.json"
    if not path.exists(): path.write_text(json.dumps({"servers": []}, indent=2), encoding="utf-8")
    return json.loads(path.read_text(encoding="utf-8"))

@app.post("/api/mcp")
def save_mcp(item: McpConfig):
    path = DATA / "mcp-config.json"
    current = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {"servers": []}
    servers = [s for s in current.get("servers", []) if s.get("name") != item.name]
    servers.append(item.model_dump())
    path.write_text(json.dumps({"servers": servers}, indent=2), encoding="utf-8")
    return {"ok": True, "servers": servers, "note": "Saved MCP configuration only. This starter does not yet launch arbitrary MCP processes or execute tools."}


# Windows desktop actions are deliberately allowlisted; arbitrary shell commands are never accepted.
SAFE_KEYS = {"enter":"enter", "return":"enter", "tab":"tab", "escape":"esc", "esc":"esc", "space":"space", "backspace":"backspace", "delete":"delete", "up":"up", "down":"down", "left":"left", "right":"right", "home":"home", "end":"end", "pageup":"pageup", "pagedown":"pagedown", "ctrl+c":"ctrl+c", "ctrl+v":"ctrl+v", "ctrl+x":"ctrl+x", "ctrl+a":"ctrl+a", "ctrl+s":"ctrl+s", "alt+tab":"alt+tab", "win":"win"}
SAFE_APPS = {"notepad":"notepad.exe", "notepad.exe":"notepad.exe", "calculator":"calc.exe", "calc":"calc.exe", "calc.exe":"calc.exe", "paint":"mspaint.exe", "mspaint":"mspaint.exe", "explorer":"explorer.exe", "file explorer":"explorer.exe", "cmd":"cmd.exe", "powershell":"powershell.exe", "task manager":"taskmgr.exe", "taskmgr":"taskmgr.exe", "chrome":"chrome.exe", "msedge":"msedge.exe", "edge":"msedge.exe", "firefox":"firefox.exe", "vscode":"code.exe", "visual studio code":"code.exe", "steam":"steam.exe", "spotify":"spotify.exe", "discord":"discord.exe"}

def resolve_app_executable(target: str) -> str | None:
    """Resolve a safe app alias through PATH and common Windows installation locations."""
    alias = SAFE_APPS.get(target.strip().lower(), target.strip())
    if Path(alias).is_file():
        return str(Path(alias).resolve())
    found = shutil.which(alias)
    if found:
        return found
    local = Path(os.getenv("LOCALAPPDATA", "C:/Users/Default/AppData/Local"))
    roaming = Path(os.getenv("APPDATA", str(local)))
    pf = Path(os.getenv("ProgramFiles", "C:/Program Files"))
    pf86 = Path(os.getenv("ProgramFiles(x86)", "C:/Program Files (x86)"))
    candidates = {
        "chrome.exe": [local / "Google/Chrome/Application/chrome.exe", pf / "Google/Chrome/Application/chrome.exe", pf86 / "Google/Chrome/Application/chrome.exe"],
        "msedge.exe": [pf / "Microsoft/Edge/Application/msedge.exe", pf86 / "Microsoft/Edge/Application/msedge.exe"],
        "firefox.exe": [pf / "Mozilla Firefox/firefox.exe", pf86 / "Mozilla Firefox/firefox.exe"],
        "steam.exe": [pf86 / "Steam/steam.exe", pf / "Steam/steam.exe"],
        "spotify.exe": [roaming / "Spotify/Spotify.exe", local / "Microsoft/WindowsApps/Spotify.exe"],
        "code.exe": [local / "Programs/Microsoft VS Code/Code.exe", pf / "Microsoft VS Code/Code.exe"],
        "notepad.exe": [Path(os.getenv("WINDIR", "C:/Windows")) / "System32/notepad.exe"],
        "calc.exe": [Path(os.getenv("WINDIR", "C:/Windows")) / "System32/calc.exe"],
        "mspaint.exe": [Path(os.getenv("WINDIR", "C:/Windows")) / "System32/mspaint.exe"],
        "explorer.exe": [Path(os.getenv("WINDIR", "C:/Windows")) / "explorer.exe"],
        "taskmgr.exe": [Path(os.getenv("WINDIR", "C:/Windows")) / "System32/taskmgr.exe"],
    }
    for candidate in candidates.get(alias.lower(), []):
        if candidate.is_file():
            return str(candidate)
    return None

@app.get("/api/desktop/status")
def desktop_status():
    return {"platform": platform.system(), "supported": platform.system() == "Windows", "actions": ["open_app", "type_text", "press_key", "click", "open_url", "stop"], "note": "Desktop control is local and limited to explicit actions; arbitrary shell execution is disabled."}

@app.post("/api/desktop/command")
def desktop_command(req: DesktopCommand):
    if platform.system() != "Windows":
        raise HTTPException(501, "Desktop automation is available only when NEXORA runs on Windows.")
    action = req.action.strip().lower()
    if action == "open_app":
        target = req.target.strip()
        if not target or len(target) > 260 or re.search(r'[&|<>^%"\n\r]', target):
            raise HTTPException(400, "Use a simple app name or a local executable path; shell syntax is not accepted.")
        alias = SAFE_APPS.get(target.lower(), target)
        try:
            executable = resolve_app_executable(target)
            if executable:
                subprocess.Popen([executable], shell=False, close_fds=True)
            elif Path(target).exists():
                os.startfile(str(Path(target).resolve()))
            else:
                raise HTTPException(404, "App not found. Try a supported app name or full .exe path.")
            return {"ok": True, "message": f"Launch request sent for {target}"}
        except HTTPException:
            raise
        except Exception as exc:
            raise HTTPException(500, f"Could not open app: {str(exc)[:180]}")
    if action == "open_url":
        url = req.target.strip()
        if not (url.startswith("https://") or url.startswith("http://")) or len(url) > 2048:
            raise HTTPException(400, "Only http:// and https:// website URLs are allowed.")
        webbrowser.open(url, new=2)
        return {"ok": True, "message": "Website opened in the default browser."}
    if action == "stop":
        try:
            import pyautogui
            pyautogui.press("esc")
            return {"ok": True, "message": "Escape sent to the active app. Use the Stop button to halt voice listening."}
        except ImportError:
            raise HTTPException(503, "Install desktop dependencies using setup_desktop.bat first.")
    try:
        import pyautogui
    except ImportError:
        raise HTTPException(503, "Desktop automation dependency is missing. Run setup_desktop.bat and restart NEXORA.")
    if action == "type_text":
        if len(req.text) > 2000:
            raise HTTPException(413, "Text is limited to 2000 characters per action.")
        if req.text.isascii():
            pyautogui.write(req.text, interval=0.005)
        else:
            try:
                import pyperclip
                pyperclip.copy(req.text)
                pyautogui.hotkey("ctrl", "v")
            except ImportError:
                raise HTTPException(503, "Unicode/Urdu typing needs pyperclip. Run setup_desktop.bat and restart NEXORA.")
        return {"ok": True, "message": f"Sent {len(req.text)} characters to the focused window."}
    if action == "press_key":
        key = req.key.strip().lower()
        if key not in SAFE_KEYS:
            raise HTTPException(400, "Key not allowed. Use enter, tab, escape, arrows, common Ctrl shortcuts, or Alt+Tab.")
        pyautogui.hotkey(*SAFE_KEYS[key].split("+")) if "+" in SAFE_KEYS[key] else pyautogui.press(SAFE_KEYS[key])
        return {"ok": True, "message": f"Sent key: {key}"}
    if action == "click":
        if req.x is None or req.y is None:
            raise HTTPException(400, "Click requires x and y screen coordinates.")
        width, height = pyautogui.size()
        if not (0 <= req.x < width and 0 <= req.y < height):
            raise HTTPException(400, f"Coordinates must be within the current screen ({width}x{height}).")
        pyautogui.click(req.x, req.y)
        return {"ok": True, "message": f"Clicked screen coordinates {req.x}, {req.y}."}
    raise HTTPException(400, "Unknown action. Supported: open_app, open_url, type_text, press_key, click, stop.")

# Curated source allowlist. Sync only fetches these fixed public GitHub raw files.
CATALOG_DIR = DATA / "catalog"
CATALOG_DIR.mkdir(parents=True, exist_ok=True)
CATALOG_CACHE = CATALOG_DIR / "catalog.json"
CATALOG_SOURCES = [
    {"id":"free-crypto-apis", "name":"Free Crypto APIs", "url":"https://github.com/narekgevorgyan/free-crypto-apis", "raw":"https://raw.githubusercontent.com/narekgevorgyan/free-crypto-apis/main/README.md", "kind":"crypto", "license":"MIT", "description":"Free/free-tier crypto APIs grouped by market data, exchange/trading, wallets, DeFi/NFT, payments, infrastructure and news."},
    {"id":"awesome-freellm-apis", "name":"awesome-free-llm-apis", "url":"https://github.com/open-free-llm-api/awesome-freellm-apis", "raw":"https://raw.githubusercontent.com/open-free-llm-api/awesome-freellm-apis/main/README.md", "kind":"llm", "license":"MIT", "description":"Directory of free-tier LLM providers, model counts, context windows, modalities, key links and configuration references."},
    {"id":"freellm-keyhub", "name":"FreeLLM-API-KeyHub", "url":"https://github.com/guihuashaoxiang/FreeLLM-API-KeyHub", "raw":"https://raw.githubusercontent.com/guihuashaoxiang/FreeLLM-API-KeyHub/main/LLM_API_Providers_All.md", "kind":"llm", "license":"Unspecified", "description":"Provider directory and free quota/offer notes. Repository states it does not provide API keys; it collects public provider information."},
    {"id":"freellms-free-llm-api-keys", "name":"Free LLM API Keys directory", "url":"https://github.com/freellms/free-llm-api-keys", "kind":"llm", "license":"Check repository", "description":"User-requested GitHub resource. Open the repository to review current content and license; no keys are scraped or bundled."},
    {"id":"freetoken", "name":"FreeToken local gateway", "url":"https://github.com/V-Groups-Foundations/freetoken", "kind":"tools", "license":"Check repository", "description":"User-requested local OpenAI-compatible gateway; install separately and configure its local token in .env."},
    {"id":"localcodecli", "name":"LocalCodeCli", "url":"https://github.com/Corporationakht/LocalCodeCli", "kind":"local-ai", "license":"Check repository", "description":"User-requested local CLI proxy reference; not executed or integrated by this catalog."},
    {"id":"openswissdata-mcp", "name":"OpenSwissData MCP", "url":"https://mcp.openswissdata.com/mcp/jsonrpc", "kind":"tools", "license":"Service terms apply", "description":"User-provided remote MCP endpoint reference. Credentials and available tools depend on the service configuration."},
    {"id":"github-topic-free-llm-api", "name":"GitHub topic: free-llm-api", "url":"https://github.com/topics/free-llm-api", "kind":"topic", "license":"Varies by repository", "description":"Live discovery page for repositories tagged free-llm-api; each repository has its own license and terms."},
    {"id":"ai-datasets", "name":"AI Datasets collection", "url":"https://github.com/goerlitz/ai-datasets", "raw":"https://raw.githubusercontent.com/goerlitz/ai-datasets/master/README.md", "kind":"datasets", "license":"GPL-3.0 (repository; dataset terms vary)", "description":"AI and machine-learning dataset references and dataset registries; links only, not full dataset downloads."},
    {"id":"awesome-public-datasets", "name":"Awesome Public Datasets", "url":"https://github.com/awesomedata/awesome-public-datasets", "raw":"https://raw.githubusercontent.com/awesomedata/awesome-public-datasets/master/README.rst", "kind":"datasets", "license":"MIT for the list; individual datasets vary", "description":"Topic-centric index of public datasets including science, government, climate, economics and machine learning."},
    {"id":"public-apis", "name":"Public APIs directory", "url":"https://github.com/public-apis/public-apis", "raw":"https://raw.githubusercontent.com/public-apis/public-apis/master/README.md", "kind":"apis", "license":"Repository license; API terms vary", "description":"Directory of public APIs grouped by use case; availability, authentication and quotas must be checked at the provider."},
    {"id":"awesome-agent-skills", "name":"Awesome Agent Skills", "url":"https://github.com/philipbankier/awesome-agent-skills", "raw":"https://raw.githubusercontent.com/philipbankier/awesome-agent-skills/main/README.md", "kind":"skills", "license":"Per repository", "description":"Directory of agent skills, MCP servers and coding-assistant extensions; review each skill before installing."},
    {"id":"anthropic-skills", "name":"Anthropic Skills", "url":"https://github.com/anthropics/skills", "raw":"https://raw.githubusercontent.com/anthropics/skills/main/README.md", "kind":"skills", "license":"See repository license", "description":"Examples and reusable skills for agent workflows; inspect instructions and dependencies before use."},
    {"id":"mcp-servers", "name":"Model Context Protocol Servers", "url":"https://github.com/modelcontextprotocol/servers", "raw":"https://raw.githubusercontent.com/modelcontextprotocol/servers/main/README.md", "kind":"tools", "license":"Per component", "description":"Reference MCP servers for controlled access to tools and data."},
    {"id":"awesome-mcp-servers", "name":"Awesome MCP Servers", "url":"https://github.com/punkpeye/awesome-mcp-servers", "raw":"https://raw.githubusercontent.com/punkpeye/awesome-mcp-servers/main/README.md", "kind":"tools", "license":"Per repository", "description":"Community MCP server directory; integrations require separate review and configuration."},
    {"id":"ollama", "name":"Ollama local AI", "url":"https://github.com/ollama/ollama", "raw":"https://raw.githubusercontent.com/ollama/ollama/main/README.md", "kind":"local-ai", "license":"MIT", "description":"Local model runner and API; install models separately and check device RAM/VRAM requirements."},
    {"id":"llama-cpp", "name":"llama.cpp", "url":"https://github.com/ggml-org/llama.cpp", "raw":"https://raw.githubusercontent.com/ggml-org/llama.cpp/master/README.md", "kind":"local-ai", "license":"MIT", "description":"Local inference engine for GGUF language models."},
    {"id":"localai", "name":"LocalAI", "url":"https://github.com/mudler/LocalAI", "raw":"https://raw.githubusercontent.com/mudler/LocalAI/master/README.md", "kind":"local-ai", "license":"MIT", "description":"OpenAI-compatible local inference API for supported models and modalities."},
    {"id":"vllm", "name":"vLLM", "url":"https://github.com/vllm-project/vllm", "raw":"https://raw.githubusercontent.com/vllm-project/vllm/main/README.md", "kind":"local-ai", "license":"Apache-2.0", "description":"High-throughput LLM serving engine; hardware and platform requirements apply."},
    {"id":"litellm", "name":"LiteLLM", "url":"https://github.com/BerriAI/litellm", "raw":"https://raw.githubusercontent.com/BerriAI/litellm/main/README.md", "kind":"local-ai", "license":"MIT", "description":"Proxy and unified interface for many model providers."},
]

def _md_cell(cell: str) -> str:
    cell = re.sub(r'<[^>]+>', '', cell)
    cell = re.sub(r'!\[([^\]]*)\]\([^)]*\)', r'\1', cell)
    cell = re.sub(r'\[([^\]]+)\]\((https?://[^)]+)\)', r'\1 (\2)', cell)
    return cell.strip().strip('`')

def _parse_markdown_tables(markdown: str, source: dict) -> list[dict]:
    rows=[]; heading='General'; lines=markdown.splitlines(); i=0
    for line in lines:
        if line.startswith('#'):
            heading=line.lstrip('#').strip()
    # Second pass preserves current heading and parses Markdown tables.
    heading='General'; i=0
    while i < len(lines):
        line=lines[i].strip()
        if line.startswith('#'):
            heading=line.lstrip('#').strip()
        if line.startswith('|') and i+1 < len(lines) and re.match(r'^\s*\|?\s*:?-{2,}', lines[i+1]):
            headers=[_md_cell(x) for x in line.strip('|').split('|')]
            i += 2
            while i < len(lines) and lines[i].strip().startswith('|'):
                cells=[_md_cell(x) for x in lines[i].strip().strip('|').split('|')]
                if len(cells) >= 2:
                    cells=(cells+['']*len(headers))[:len(headers)]
                    item={headers[j] or f'column_{j+1}':cells[j] for j in range(len(headers))}
                    # Drop navigation tables and rows without useful data.
                    if any(v for k,v in item.items() if k.lower() not in ('api','provider','service provider name','name')):
                        rows.append({"source_id":source["id"],"source_name":source["name"],"source_url":source["url"],"category":heading,"data":item})
                i += 1
            continue
        i += 1
    # Also index ordinary Markdown and reStructuredText link lists (useful for dataset/skills catalogs).
    seen_links=set(); link_heading='General'
    for raw_line in lines:
        line=raw_line.strip()
        if line.startswith('#'):
            link_heading=line.lstrip('#').strip()
        if not line or len(line)>1200:
            continue
        markdown_match=re.match(r'^[-*+]\s+\[([^\]]+)\]\((https?://[^)]+)\)(.*)$', line)
        rst_match=re.match(r'^[-*+]\s+`([^`]+?)\s*<((?:https?://)[^>]+)>`_(.*)$', line)
        match=markdown_match or rst_match
        if not match:
            continue
        title,url,tail=match.groups()
        url=url.rstrip('.,;)')
        if url in seen_links or url.rstrip('/').startswith(source['url'].rstrip('/')):
            continue
        seen_links.add(url)
        rows.append({"source_id":source["id"],"source_name":source["name"],"source_url":source["url"],"category":link_heading if link_heading != 'General' else source.get('kind','General'),"data":{"name":title.strip(),"url":url,"description":re.sub(r'[`*_]','',tail).strip()[:500] or line[:500]}})
        if len(seen_links)>=1200:
            break
    return rows

@app.get("/api/catalog")
def get_catalog():
    if CATALOG_CACHE.exists():
        try: cached=json.loads(CATALOG_CACHE.read_text(encoding='utf-8'))
        except Exception: cached={}
    else: cached={}
    return {"sources":CATALOG_SOURCES,"last_sync":cached.get("last_sync"),"count":len(cached.get("entries",[])),"entries":cached.get("entries",[]),"note":"Free-tier information changes. Confirm current quotas and terms on each provider's official site."}

@app.post("/api/catalog/sync")
async def sync_catalog():
    entries=[]; source_status=[]
    async with httpx.AsyncClient(timeout=20.0, follow_redirects=False, headers={"User-Agent":"NEXORA-Forge-Local-Catalog/2.0"}) as client:
        for source in CATALOG_SOURCES:
            raw_url=source.get("raw")
            if not raw_url:
                source_status.append({"id":source["id"],"status":"link-only","entries":0})
                continue
            try:
                response=await client.get(raw_url)
                if not response.is_success: raise RuntimeError(f"HTTP {response.status_code}")
                if len(response.content)>2_000_000: raise RuntimeError("Source exceeds 2 MB safety limit")
                text_content=response.text
                parsed=_parse_markdown_tables(text_content,source)
                entries.extend(parsed)
                source_status.append({"id":source["id"],"status":"synced","entries":len(parsed),"fetched_bytes":len(response.content)})
            except Exception as exc:
                source_status.append({"id":source["id"],"status":"failed","entries":0,"detail":str(exc)[:180]})
    payload={"last_sync":time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),"entries":entries,"source_status":source_status}
    CATALOG_CACHE.write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')
    return {"ok":bool(entries),"last_sync":payload["last_sync"],"count":len(entries),"source_status":source_status,"note":"Catalog data only; this does not import or execute repository code and does not create API keys."}

@app.get("/api/info")
def info():
    return {"features": ["AI chat through OpenAI-compatible endpoints", "local provider status/model discovery", "FreeToken gateway configuration", "local attachments", "project scaffolding", "MCP configuration registry", "server-side API key environment variables", "curated GitHub dataset/API/skills/MCP/local-AI resource catalog", "limited Windows desktop actions and browser speech-recognition voice input"], "not_yet_implemented": ["live MCP tool execution and approval UI", "AI multi-file editing and automated tests", "video generation provider integration", "APK compilation/signing", "Google OAuth and account system", "production authentication and remote access"]}

HTML = r'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>NEXORA Forge 2.1</title><style>
:root{color-scheme:dark;--bg:#090c16;--panel:#111729;--line:#26324d;--muted:#9caac8;--text:#eef3ff;--cyan:#57e4f2;--violet:#9a8cff}*{box-sizing:border-box}body{margin:0;background:radial-gradient(ellipse at 10% 0%,#1c2850 0,transparent 45%),var(--bg);color:var(--text);font:15px system-ui,Segoe UI,sans-serif}.app{display:grid;grid-template-columns:245px 1fr;min-height:100vh}.side{border-right:1px solid var(--line);padding:24px 16px;background:#0a0e1bde}.logo{font-weight:900;letter-spacing:2px;font-size:20px}.logo span{color:var(--cyan)}.sub{color:var(--muted);font-size:12px;margin:6px 0 28px}.nav{display:grid;gap:8px}.nav button{background:transparent;border:1px solid transparent;color:#c9d4f0;text-align:left;padding:12px;border-radius:12px;cursor:pointer}.nav button.active,.nav button:hover{background:#17233d;border-color:#304466;color:white}.foot{margin-top:32px;color:var(--muted);font-size:12px;line-height:1.6}.main{padding:26px;min-width:0;max-width:1500px;width:100%;margin:auto}.top{display:flex;justify-content:space-between;gap:14px;align-items:center;flex-wrap:wrap;margin-bottom:24px}.eyebrow{color:var(--cyan);font-size:11px;font-weight:800;letter-spacing:2px}.h1{font-size:clamp(25px,4vw,38px);font-weight:850;margin:4px 0}.muted{color:var(--muted)}.pill{border:1px solid #31536b;color:#a8f6ff;padding:7px 10px;border-radius:99px;font-size:12px}.grid{display:grid;grid-template-columns:repeat(12,minmax(0,1fr));gap:16px}.card{background:linear-gradient(145deg,#151d31,#0f1424);border:1px solid var(--line);border-radius:17px;padding:18px;min-width:0}.span12{grid-column:span 12}.span8{grid-column:span 8}.span6{grid-column:span 6}.span4{grid-column:span 4}h2{font-size:17px;margin:0 0 12px}h3{font-size:14px;margin:0 0 8px}.row{display:flex;gap:10px;align-items:center;flex-wrap:wrap}.field{width:100%;background:#090e1b;border:1px solid #2b3955;color:white;padding:11px;border-radius:10px;outline:none}.field:focus{border-color:var(--cyan)}label{font-size:12px;color:#b5c3df;display:block;margin:10px 0 6px}.btn{border:0;background:linear-gradient(110deg,#3bd5e7,#9a8cff);color:#06101c;font-weight:800;padding:11px 14px;border-radius:10px;cursor:pointer}.btn.secondary{background:#1b2943;color:#e4edff;border:1px solid #334765}.status{padding:8px 10px;border-radius:9px;background:#0b1322;border:1px solid var(--line);font-size:12px;display:flex;justify-content:space-between;gap:10px}.good{color:#7ef0b0}.bad{color:#ffb4aa}.messages{height:300px;overflow:auto;display:flex;flex-direction:column;gap:10px;padding:4px}.msg{white-space:pre-wrap;overflow-wrap:anywhere;max-width:95%;padding:12px;border-radius:12px;background:#1b2943}.msg.user{align-self:flex-end;background:#26335a}.msg.assistant{align-self:flex-start}.hidden{display:none!important}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#080d18;padding:12px;border-radius:10px;color:#c8d9f8;font-size:12px}.small{font-size:12px}.notice{border-left:3px solid #e6bf64;padding:10px 12px;background:#231e15;color:#e8d9b4;border-radius:6px;font-size:12px;line-height:1.5}@media(max-width:850px){.app{grid-template-columns:1fr}.side{border-right:0;border-bottom:1px solid var(--line);padding:14px}.nav{grid-template-columns:repeat(3,1fr)}.nav button{font-size:12px;padding:9px}.foot{display:none}.main{padding:15px}.span8,.span6,.span4{grid-column:span 12}}
</style></head><body><div class="app"><aside class="side"><div class="logo">NEXORA <span>FORGE</span></div><div class="sub">AI WORKSPACE • LOCAL DESKTOP EDITION 2.1</div><div class="nav"><button class="active" data-page="overview">◈ Overview</button><button data-page="chat">✧ AI Workspace</button><button data-page="desktop">⌨ Desktop Control</button><button data-page="providers">◎ AI Providers</button><button data-page="catalog">⌕ API Catalog</button><button data-page="projects">▣ Project Studio</button><button data-page="tools">⌘ Tools & MCP</button><button data-page="files">⇧ Attachments</button></div><div class="foot">Local-first workspace<br>Keys stay in backend .env<br><br>Never expose this server publicly without authentication.</div></aside><main class="main"><div class="top"><div><div class="eyebrow">YOUR PERSONAL AI OPERATING SPACE</div><div class="h1" id="pagetitle">Build beyond limits.</div><div class="muted" id="pagesub">Your providers, code projects and tools in one local workspace.</div></div><div class="pill">● LOCALHOST MODE</div></div>
<section id="overview" class="page"><div class="grid"><div class="card span8"><div class="eyebrow">NEXORA FORGE 2.0</div><h2 style="font-size:24px;margin-top:8px">One workspace. Multiple AI engines.</h2><p class="muted">Connect local models, cloud providers and the FreeToken OpenAI-compatible gateway. Build project scaffolds, manage attachments and keep configuration on your PC.</p><div class="row"><button class="btn" onclick="showPage('chat')">Open AI Workspace</button><button class="btn secondary" onclick="showPage('providers')">Configure Providers</button></div></div><div class="card span4"><h2>Workspace status</h2><div id="statusSummary" class="muted">Checking configured endpoints…</div><button class="btn secondary" style="margin-top:12px" onclick="refreshStatus()">Refresh status</button></div><div class="card span12"><h2>System modules</h2><div class="grid"><div class="card span4"><h3>AI & routing</h3><p class="muted small">OpenAI-compatible chat, model discovery, FreeToken gateway configuration.</p></div><div class="card span4"><h3>Project Studio</h3><p class="muted small">Create starter web projects locally. Production builds require the target toolchain.</p></div><div class="card span4"><h3>Tools & MCP</h3><p class="muted small">Save MCP server definitions. Tool execution is not enabled in this starter.</p></div></div></div><div class="card span12"><div class="notice">This is a local starter implementation. It does not automatically grant provider quotas or generate legitimate provider API keys. Add your own keys in the backend .env file. FreeToken is a separate service that must be installed and started independently.</div></div></div></section>
<section id="chat" class="page hidden"><div class="grid"><div class="card span12"><h2>AI Workspace</h2><div class="row"><div style="flex:1;min-width:190px"><label>Provider</label><select id="provider" class="field"></select></div><div style="flex:1;min-width:190px"><label>Model ID</label><input id="model" class="field" value="auto-smart" placeholder="e.g. auto-smart"></div><button class="btn secondary" style="margin-top:28px" onclick="loadModels()">List models</button></div><div id="modelresult" class="small muted" style="margin-top:8px"></div><div class="messages" id="messages" style="margin-top:14px"><div class="msg assistant">Hello! Select a provider and model, then send a message.</div></div><label>Message</label><textarea id="prompt" class="field" rows="3" placeholder="Ask for help, code, debugging, planning…"></textarea><div class="row" style="margin-top:10px"><button class="btn" onclick="sendChat()">Send message</button><button class="btn secondary" onclick="clearChat()">Clear chat</button><span id="chatstatus" class="muted small"></span></div></div></div></section>
<section id="desktop" class="page hidden"><div class="grid"><div class="card span12"><h2>Voice & Desktop Control</h2><p class="muted small">Works when NEXORA runs on Windows. Browser speech recognition depends on your browser and microphone permission. This starter supports explicit, limited actions; it does not run arbitrary shell commands.</p><div class="row"><button class="btn" onclick="startVoice()">🎙 Start voice command</button><button class="btn secondary" onclick="stopVoice()">■ Stop listening</button><button class="btn secondary" onclick="desktopCommand({action:'stop'})">Send Escape</button><select id="voicelanguage" class="field" style="max-width:180px"><option value="en-US">English</option><option value="ur-PK">اردو</option></select><span id="voicestatus" class="muted small">Ready</span></div><label>Voice transcript / command</label><input id="voicecommand" class="field" placeholder="Try: open notepad, type Hello world, press enter, click 400 300"><div class="row" style="margin-top:10px"><button class="btn" onclick="runVoiceCommand(document.getElementById('voicecommand').value)">Run command</button><button class="btn secondary" onclick="desktopStatus()">Check desktop support</button></div><pre id="desktopresult">Desktop actions have not been checked yet.</pre><div class="notice">Safety: open-app, URL, typing, keypress and coordinate click actions only. No arbitrary command shell, credential extraction, stealth or destructive file actions. Confirm important actions yourself in the target app.</div></div><div class="card span6"><h2>Supported voice examples</h2><ul class="muted small"><li>“Open Notepad” / “Open Chrome” / “Open Steam”</li><li>“Open website https://example.com”</li><li>“Type Hello, this is NEXORA”</li><li>“Press Enter” / “Press Ctrl+S” / “Press Alt+Tab”</li><li>“Click 400 300” using screen coordinates</li><li>“Stop, NEXORA” to stop listening and send Escape</li></ul></div><div class="card span6"><h2>Desktop automation dependency</h2><p class="muted small">The optional pyautogui package is needed for typing/clicking/keypresses. Run setup_desktop.bat on Windows. For robust app controls, the next integration can add pywinauto UI Automation.</p><a href="https://github.com/pywinauto/pywinauto" target="_blank" rel="noopener">pywinauto GitHub ↗</a></div></div></section>
<section id="providers" class="page hidden"><div class="grid"><div class="card span12"><h2>Provider connections</h2><p class="muted small">Status checks try the configured /models endpoint. Add cloud keys to .env and restart the app. Local provider ports can be changed there too.</p><div id="providerlist" class="grid"></div><div class="notice" style="margin-top:14px">If two local services use port 8080, assign one a different port. This starter defaults LocalAI to 8081 and llama.cpp to 8080.</div></div><div class="card span12"><h2>Environment setup</h2><p class="muted">Edit <code>.env</code> in the project folder. Do not paste keys into this web page or commit them to Git.</p><pre>FREETOKEN_BASE_URL=http://127.0.0.1:3000/api/v1
FREETOKEN_API_KEY=your_local_freetoken_token
GEMINI_API_KEY=your_key_here
GROQ_API_KEY=your_key_here
OPENROUTER_API_KEY=your_key_here</pre></div></div></section>
<section id="catalog" class="page hidden"><div class="grid"><div class="card span12"><h2>Unified Resource Catalog</h2><p class="muted small">Sync public provider-directory data from the repositories you supplied. Only fixed, public README/Markdown sources are read; repository code is not executed and provider API keys are never collected.</p><div class="row"><button class="btn" onclick="syncCatalog()">Sync catalog data</button><button class="btn secondary" onclick="loadCatalog()">Refresh saved data</button><span id="catalogstatus" class="muted small">Not synced yet</span></div><label>Search providers, categories or use-cases</label><input id="catalogsearch" class="field" placeholder="e.g. CoinGecko, Binance Futures, Gemini, free tier" oninput="renderCatalog()"><div class="row" style="margin-top:10px"><select id="catalogfilter" class="field" style="max-width:260px" onchange="renderCatalog()"><option value="all">All categories</option><option value="llm">LLM / AI providers</option><option value="crypto">Crypto APIs</option><option value="datasets">Datasets</option><option value="apis">Public APIs</option><option value="skills">Agent skills</option><option value="tools">MCP & tools</option><option value="local-ai">Local AI</option><option value="topic">GitHub topics</option></select><a href="https://github.com/topics/free-llm-api" target="_blank" rel="noopener">Browse GitHub free-LLM topic ↗</a></div><div id="catalogsources" class="grid" style="margin-top:14px"></div><div id="catalogresults" class="grid" style="margin-top:14px"></div></div></div></section><section id="projects" class="page hidden"><div class="grid"><div class="card span6"><h2>Create a project</h2><label>Project name</label><input id="projectname" class="field" placeholder="My Web App"><label>Description</label><textarea id="projectdesc" class="field" rows="3" placeholder="What should this project do?"></textarea><label>Project type</label><select id="projectkind" class="field"><option value="web">Web project</option><option value="api">API/backend scaffold</option><option value="android">Android project plan (not APK build)</option></select><button class="btn" style="margin-top:12px" onclick="createProject()">Create locally</button><div id="projectresult" class="small muted" style="margin-top:12px"></div></div><div class="card span6"><h2>Your projects</h2><button class="btn secondary" onclick="listProjects()">Refresh projects</button><div id="projectslist" style="margin-top:12px" class="muted small"></div></div><div class="card span12"><h2>Build and APK status</h2><p class="muted">This starter can create a web starter. It does not yet convert arbitrary projects to signed APKs. For that, the next implementation step is a validated WebView/Capacitor build pipeline with Android SDK, Java and signing configuration.</p></div></div></section>
<section id="tools" class="page hidden"><div class="grid"><div class="card span6"><h2>Add MCP server configuration</h2><label>Server name</label><input id="mcpname" class="field" placeholder="openswissdata"><label>Command (local stdio, optional)</label><input id="mcpcommand" class="field" placeholder="npx"><label>Arguments (comma separated)</label><input id="mcpargs" class="field" placeholder="-y,@openswissdata/mcp"><label>Remote URL (optional)</label><input id="mcpurl" class="field" placeholder="https://…/mcp/jsonrpc"><button class="btn" style="margin-top:12px" onclick="saveMcp()">Save configuration</button><p class="muted small">Saving does not execute the server. Review command and URL before enabling future tool execution.</p></div><div class="card span6"><h2>Saved MCP servers</h2><button class="btn secondary" onclick="loadMcp()">Refresh</button><pre id="mcplist">No configurations loaded.</pre></div><div class="card span12"><h2>Planned workspace tools</h2><div class="grid"><div class="card span4"><h3>Code & project editing</h3><p class="muted small">Multi-file edits, diffs, tests and repair loop are future module work.</p></div><div class="card span4"><h3>Video generation</h3><p class="muted small">Requires an actual video provider and credentials; not falsely simulated.</p></div><div class="card span4"><h3>Local CLI integration</h3><p class="muted small">LocalCodeCli integration needs its repository cloned and reviewed before wiring routes.</p></div></div></div></div></section>
<section id="files" class="page hidden"><div class="grid"><div class="card span6"><h2>Attach files</h2><p class="muted small">Uploads are saved to this PC in data/uploads. Uploads are not automatically executed.</p><input type="file" id="fileinput" class="field"><button class="btn" style="margin-top:12px" onclick="uploadFile()">Upload attachment</button><div id="uploadresult" class="muted small" style="margin-top:12px"></div></div><div class="card span6"><h2>Security & privacy</h2><ul class="muted small"><li>API keys stay server-side in .env.</li><li>Do not expose localhost port 8787 publicly.</li><li>Uploaded files are stored locally and are not scanned or run.</li><li>Keep backups of projects and configuration.</li></ul></div></div></section>
</main></div><script>
let historyMessages=[{role:'system',content:'You are NEXORA Forge, a helpful coding and project assistant. Do not claim tools were run unless they were.'}];
const pageText={desktop:['Voice & Desktop Control','Control supported Windows apps with explicit voice commands.'],overview:['Build beyond limits.','Your providers, code projects and tools in one local workspace.'],chat:['AI Workspace','Chat with a configured OpenAI-compatible model.'],providers:['AI Providers','Local models, cloud providers and FreeToken gateway.'],catalog:['Unified Resource Catalog','Search GitHub APIs, datasets, agent skills, MCP servers and local AI references.'],projects:['Project Studio','Create and manage local project scaffolds.'],tools:['Tools & MCP','Configure MCP endpoints and local tool servers.'],files:['Attachments','Store project files locally.']};
function showPage(p){document.querySelectorAll('.page').forEach(x=>x.classList.add('hidden'));document.getElementById(p).classList.remove('hidden');document.querySelectorAll('.nav button').forEach(b=>b.classList.toggle('active',b.dataset.page===p));document.getElementById('pagetitle').textContent=pageText[p][0];document.getElementById('pagesub').textContent=pageText[p][1];if(p==='desktop')desktopStatus();if(p==='providers')refreshStatus();if(p==='projects')listProjects();if(p==='tools')loadMcp();if(p==='catalog')loadCatalog()}
document.querySelectorAll('.nav button').forEach(b=>b.addEventListener('click',()=>showPage(b.dataset.page)));
async function api(path,opts={}){let r=await fetch(path,opts);let j=await r.json().catch(()=>({detail:r.statusText}));if(!r.ok)throw Error(j.detail||'Request failed');return j}
async function init(){try{let j=await api('/api/providers');let s=document.getElementById('provider');s.innerHTML='';j.providers.forEach(p=>{let o=document.createElement('option');o.value=p.name;o.textContent=p.name+(p.configured?'':' (key needed)');s.appendChild(o)});s.value='FreeToken';await refreshStatus()}catch(e){console.error(e)}}
async function refreshStatus(){let el=document.getElementById('statusSummary'),list=document.getElementById('providerlist');try{let j=await api('/api/status');let online=j.providers.filter(p=>p.online).length;el.innerHTML=`<b>${online}</b> endpoints responding out of ${j.providers.length}<div class="muted small">FreeToken: ${j.freetoken_base_url}</div>`;list.innerHTML=j.providers.map(p=>`<div class="status" style="grid-column:span 6"><span>${p.name}<br><small class="muted">${p.detail}${p.configured?'':' · key not set'}</small></span><b class="${p.online?'good':'bad'}">${p.online?'ONLINE':'OFFLINE'}</b></div>`).join('')}catch(e){el.textContent=e.message}}
async function loadModels(){let p=document.getElementById('provider').value;document.getElementById('modelresult').textContent='Loading…';try{let j=await api('/api/models/'+encodeURIComponent(p.replaceAll('/','__')));let ms=(j.data||j.models||[]).map(m=>m.id||m.name).filter(Boolean);document.getElementById('modelresult').textContent=ms.length?'Models: '+ms.join(', '):JSON.stringify(j).slice(0,700);if(ms.length)document.getElementById('model').value=ms[0]}catch(e){document.getElementById('modelresult').textContent=e.message}}
function addMessage(role,text){let d=document.createElement('div');d.className='msg '+role;d.textContent=text;document.getElementById('messages').appendChild(d);d.scrollIntoView({block:'end'})}
async function sendChat(){let input=document.getElementById('prompt'),text=input.value.trim();if(!text)return;input.value='';addMessage('user',text);historyMessages.push({role:'user',content:text});let status=document.getElementById('chatstatus');status.textContent='Thinking…';try{let j=await api('/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({provider:document.getElementById('provider').value,model:document.getElementById('model').value.trim()||'auto-smart',messages:historyMessages})});let answer=j.choices?.[0]?.message?.content||JSON.stringify(j);addMessage('assistant',answer);historyMessages.push({role:'assistant',content:answer});status.textContent='Done'}catch(e){addMessage('assistant','Error: '+e.message);status.textContent='Failed'}}
function clearChat(){historyMessages=historyMessages.slice(0,1);document.getElementById('messages').innerHTML='';document.getElementById('chatstatus').textContent=''}
async function createProject(){let n=document.getElementById('projectname').value.trim();if(!n)return alert('Enter a project name');try{let j=await api('/api/projects',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:n,description:document.getElementById('projectdesc').value,kind:document.getElementById('projectkind').value})});document.getElementById('projectresult').textContent='Created at: '+j.folder+' · '+j.files.join(', ');listProjects()}catch(e){document.getElementById('projectresult').textContent=e.message}}
async function listProjects(){try{let j=await api('/api/projects');document.getElementById('projectslist').innerHTML=j.projects.length?j.projects.map(p=>`<div class="status" style="margin-top:8px"><span>${p.name}<br><small class="muted">${p.files.join(', ')}</small></span></div>`).join(''):'No projects created yet.'}catch(e){document.getElementById('projectslist').textContent=e.message}}
async function uploadFile(){let f=document.getElementById('fileinput').files[0];if(!f)return alert('Choose a file first');let d=new FormData();d.append('file',f);try{let j=await api('/api/upload',{method:'POST',body:d});document.getElementById('uploadresult').textContent=`Saved ${j.filename} (${j.bytes} bytes) as data/uploads/${j.stored_as}`}catch(e){document.getElementById('uploadresult').textContent=e.message}}
let catalogData={sources:[],entries:[],last_sync:null};
async function loadCatalog(){try{catalogData=await api('/api/catalog');document.getElementById('catalogstatus').textContent=catalogData.last_sync?`Last sync: ${catalogData.last_sync} · ${catalogData.count} rows`:'No saved sync yet — click Sync catalog data';renderCatalog()}catch(e){document.getElementById('catalogstatus').textContent=e.message}}
async function syncCatalog(){let el=document.getElementById('catalogstatus');el.textContent='Fetching public source data…';try{let j=await api('/api/catalog/sync',{method:'POST'});el.textContent=`Sync ${j.ok?'finished':'incomplete'} · ${j.count} table rows`;await loadCatalog();if(j.source_status.some(s=>s.status==='failed'))el.textContent+=' · one or more sources failed; retry later'}catch(e){el.textContent='Sync failed: '+e.message}}
function renderCatalog(){let sourceEl=document.getElementById('catalogsources'),results=document.getElementById('catalogresults');if(!sourceEl||!results)return;sourceEl.innerHTML=(catalogData.sources||[]).map(s=>`<div class="card span6"><h3>${escapeHtml(s.name)}</h3><p class="muted small">${escapeHtml(s.description)}</p><div class="row"><a href="${s.url}" target="_blank" rel="noopener">Open repository ↗</a><span class="muted small">License: ${escapeHtml(s.license)}</span></div></div>`).join('');let q=(document.getElementById('catalogsearch')?.value||'').toLowerCase(),f=document.getElementById('catalogfilter')?.value||'all';let entries=(catalogData.entries||[]).filter(e=>{let src=(catalogData.sources||[]).find(s=>s.id===e.source_id);if(f!=='all'&&src?.kind!==f)return false;return (e.category+' '+Object.values(e.data||{}).join(' ')).toLowerCase().includes(q)});results.innerHTML=entries.slice(0,250).map(e=>{let values=Object.entries(e.data||{}).map(([k,v])=>`<div class="small"><b>${escapeHtml(k)}:</b> ${escapeHtml(v)}</div>`).join('');return `<div class="card span6"><div class="eyebrow">${escapeHtml(e.category)}</div>${values}<p class="small"><a href="${e.source_url}" target="_blank" rel="noopener">Source: ${escapeHtml(e.source_name)} ↗</a></p></div>`}).join('');if(!entries.length)results.innerHTML='<div class="card span12"><p class="muted">No catalog rows saved yet, or no results match your search. Click Sync catalog data while connected to the internet.</p></div>';else if(entries.length>250)results.insertAdjacentHTML('beforeend','<div class="card span12"><p class="muted small">Showing first 250 matching rows. Narrow your search to see more.</p></div>')}
function escapeHtml(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
async function loadMcp(){try{document.getElementById('mcplist').textContent=JSON.stringify(await api('/api/mcp'),null,2)}catch(e){document.getElementById('mcplist').textContent=e.message}}
async function saveMcp(){let name=document.getElementById('mcpname').value.trim();if(!name)return alert('Enter a server name');try{let j=await api('/api/mcp',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name,command:document.getElementById('mcpcommand').value.trim(),args:document.getElementById('mcpargs').value.split(',').map(x=>x.trim()).filter(Boolean),url:document.getElementById('mcpurl').value.trim()})});document.getElementById('mcplist').textContent=JSON.stringify(j,null,2)}catch(e){document.getElementById('mcplist').textContent=e.message}}
async function desktopStatus(){try{let j=await api('/api/desktop/status');document.getElementById('desktopresult').textContent=JSON.stringify(j,null,2);document.getElementById('voicestatus').textContent=j.supported?'Windows desktop control available':'Desktop actions require Windows'}catch(e){document.getElementById('desktopresult').textContent=e.message}}
async function desktopCommand(payload){try{let j=await api('/api/desktop/command',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});document.getElementById('desktopresult').textContent=j.message||JSON.stringify(j);document.getElementById('voicestatus').textContent='Command sent';return j}catch(e){document.getElementById('desktopresult').textContent='Error: '+e.message;document.getElementById('voicestatus').textContent='Command failed';throw e}}
function normalizeKey(s){let k=s.trim().toLowerCase().replace(/\s+plus\s+/g,'+').replace(/control/g,'ctrl');return ({'return':'enter','escape':'escape','control+s':'ctrl+s','control+c':'ctrl+c','control+v':'ctrl+v','control+x':'ctrl+x','control+a':'ctrl+a'}[k]||k)}
async function runVoiceCommand(raw){let t=String(raw||'').trim();if(!t)return;document.getElementById('voicecommand').value=t;let low=t.toLowerCase();if(/^(stop|stop listening|stop nexora)([,! ]|$)/.test(low)||/^(رکو|بس کرو|نیکزورا بند کرو)/.test(low)){stopVoice();try{await desktopCommand({action:'stop'})}catch(e){}return}
const urduApps=[[/^(?:نوٹ پیڈ|نوٹ پیڈ ایپ) کھولو$/, 'notepad'],[/^کروم کھولو$/, 'chrome'],[/^(?:کیلکولیٹر|کیلکولیٹر ایپ) کھولو$/, 'calculator'],[/^(?:فائل ایکسپلورر|ایکسپلورر) کھولو$/, 'explorer'],[/^اسٹیم کھولو$/, 'steam']];for(const [rx,appName] of urduApps){if(rx.test(t))return desktopCommand({action:'open_app',target:appName})}
let um=t.match(/^(?:یہ لکھو|لکھو)\s+([\s\S]+)$/);if(um)return desktopCommand({action:'type_text',text:um[1]});if(/^(?:انٹر|اینٹر) دباؤ$/.test(t))return desktopCommand({action:'press_key',key:'enter'});if(/^ٹیب دباؤ$/.test(t))return desktopCommand({action:'press_key',key:'tab'});
let m=t.match(/^open\s+(?:website\s+)?(https?:\/\/\S+)$/i);if(m)return desktopCommand({action:'open_url',target:m[1]});
m=t.match(/^open\s+(.+)$/i);if(m)return desktopCommand({action:'open_app',target:m[1].trim()});
m=t.match(/^(?:type|write)\s+([\s\S]+)$/i);if(m)return desktopCommand({action:'type_text',text:m[1]});
m=t.match(/^press\s+(.+)$/i);if(m)return desktopCommand({action:'press_key',key:normalizeKey(m[1])});
m=t.match(/^click\s+(\d+)\s*[, ]\s*(\d+)$/i);if(m)return desktopCommand({action:'click',x:Number(m[1]),y:Number(m[2])});
document.getElementById('desktopresult').textContent='Command not recognized. Try: open Notepad, type Hello, press Enter, or click 400 300.';}
let speechRecognition=null;
function startVoice(){const SR=window.SpeechRecognition||window.webkitSpeechRecognition;if(!SR){document.getElementById('voicestatus').textContent='Speech recognition is not supported in this browser; type the command instead.';return}stopVoice();speechRecognition=new SR();speechRecognition.lang=document.getElementById('voicelanguage')?.value||'en-US';speechRecognition.interimResults=false;speechRecognition.maxAlternatives=1;speechRecognition.onresult=e=>{let t=e.results[0][0].transcript;document.getElementById('voicecommand').value=t;runVoiceCommand(t).catch(()=>{})};speechRecognition.onerror=e=>{document.getElementById('voicestatus').textContent='Voice error: '+e.error};speechRecognition.onend=()=>{document.getElementById('voicestatus').textContent='Voice listening stopped'};speechRecognition.start();document.getElementById('voicestatus').textContent='Listening… say one command';}
function stopVoice(){if(speechRecognition){try{speechRecognition.stop()}catch(e){}speechRecognition=null}document.getElementById('voicestatus').textContent='Stopped listening'}
init();
</script></body></html>'''
