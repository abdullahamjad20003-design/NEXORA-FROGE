"""Windows single-file launcher for NEXORA Forge. The backend stays bound to localhost."""
from __future__ import annotations
import os, sys, shutil, threading, time, webbrowser
from pathlib import Path

ROOT = Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parent
# In a PyInstaller one-file build, bundled read-only assets live under _MEIPASS.
if not (ROOT / ".env").exists():
    bundled_example = Path(getattr(sys, "_MEIPASS", ROOT)) / ".env.example"
    if bundled_example.exists():
        try:
            shutil.copy2(bundled_example, ROOT / ".env.example")
            shutil.copy2(bundled_example, ROOT / ".env")
        except OSError:
            pass

import tkinter as tk
from tkinter import messagebox
import uvicorn
from app import app

HOST = "127.0.0.1"
PORT = 8787
server = None
server_thread = None

def start_server():
    global server, server_thread
    if server_thread and server_thread.is_alive():
        return
    config = uvicorn.Config(app, host=HOST, port=PORT, log_level="critical", access_log=False)
    server = uvicorn.Server(config)
    server_thread = threading.Thread(target=server.run, daemon=True)
    server_thread.start()
    status_var.set("Starting NEXORA…")
    root.after(1200, open_workspace)

def open_workspace():
    webbrowser.open(f"http://{HOST}:{PORT}", new=2)
    status_var.set(f"Running locally at http://{HOST}:{PORT}")

def stop_server():
    if server:
        server.should_exit = True
    root.after(250, root.destroy)

def on_close():
    if messagebox.askyesno("Close NEXORA", "Stop NEXORA Forge and close the launcher?"):
        stop_server()

root = tk.Tk()
root.title("NEXORA Forge Desktop")
root.geometry("420x230")
root.resizable(False, False)
root.configure(bg="#0b1020")
status_var = tk.StringVar(value="Ready to start")
tk.Label(root, text="NEXORA FORGE", font=("Segoe UI", 20, "bold"), fg="#66e6f2", bg="#0b1020").pack(pady=(22, 4))
tk.Label(root, text="Local AI workspace • Windows desktop launcher", font=("Segoe UI", 9), fg="#c9d5f0", bg="#0b1020").pack()
tk.Label(root, textvariable=status_var, font=("Segoe UI", 9), fg="#b8c5df", bg="#0b1020", wraplength=380).pack(pady=15)
row = tk.Frame(root, bg="#0b1020")
row.pack()
tk.Button(row, text="Open NEXORA", command=start_server, width=16, bg="#54d9e8", fg="#06101c", relief="flat").pack(side="left", padx=6)
tk.Button(row, text="Open workspace", command=open_workspace, width=16, bg="#1b2943", fg="#eef3ff", relief="flat").pack(side="left", padx=6)
tk.Button(root, text="Stop & Exit", command=on_close, bg="#33253a", fg="#ffe8ee", relief="flat").pack(pady=12)
root.protocol("WM_DELETE_WINDOW", on_close)
root.after(300, start_server)
root.mainloop()
