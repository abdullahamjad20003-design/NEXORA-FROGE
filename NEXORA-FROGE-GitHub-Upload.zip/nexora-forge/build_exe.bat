@echo off
setlocal
cd /d "%~dp0"
if not exist .venv (
  py -3 -m venv .venv
  if errorlevel 1 (echo Python 3.11+ is required. Install it from python.org and enable Add to PATH.& pause & exit /b 1)
)
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -r requirements.txt pyautogui pywinauto pyperclip pyinstaller
if not exist .env copy .env.example .env
pyinstaller --noconfirm --clean --onefile --windowed --name NEXORA-Forge --add-data ".env.example;." --collect-all uvicorn --collect-all fastapi --collect-all starlette --collect-all pyautogui desktop_launcher.py
if errorlevel 1 (echo Build failed. Read the error above; do not assume an EXE was created.& pause & exit /b 1)
echo.
echo Build complete. Check dist\NEXORA-Forge.exe and test it on this PC.
echo Keep your .env file beside the EXE; never share it.
pause
