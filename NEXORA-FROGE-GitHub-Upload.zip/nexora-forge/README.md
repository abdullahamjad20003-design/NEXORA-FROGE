# NEXORA Forge 2.1

**A local-first AI workspace starter for Windows.** NEXORA Forge provides a browser-based local dashboard for OpenAI-compatible AI endpoints, provider configuration, file uploads, basic web-project scaffolding, an API/resource catalog, and saved MCP configuration.

> **Project status:** this is a starter implementation, not a fully autonomous Jarvis/Codex replacement. Read [Current implementation and limitations](#current-implementation-and-limitations) before relying on any feature.

## Contents

- `app.py` — FastAPI application and local dashboard
- `desktop_launcher.py` — desktop launcher
- `run.bat` — create a Python environment, install dependencies, and run the local app
- `setup_desktop.bat` — Windows desktop shortcut setup helper
- `build_exe.bat` — build a Windows executable with PyInstaller
- `.env.example` — blank/configuration template; copy to `.env`
- `requirements.txt` — Python runtime dependencies
- `tests/smoke_test.py` — basic smoke checks
- `docs/COMMANDS.md` — setup, run, Git and build commands
- `docs/SECURITY.md` — API-key and desktop-automation safety notes
- `docs/RESOURCES.md` — GitHub, local-model, API and MCP references

## Requirements

- Windows 10 or Windows 11 (recommended for the supplied `.bat` scripts)
- Python 3.11 or newer, available as `py -3`
- Internet access for installing Python packages and using cloud AI providers
- Optional local AI service: Ollama, LM Studio, llama.cpp server, vLLM, LocalAI, Jan, or LiteLLM
- Optional Node.js 20.9+ if you separately install FreeToken

## Quick start (Windows)

1. Download this repository using **Code → Download ZIP**, then extract it to a normal writable folder, for example `C:\NEXORA-Forge`.
2. Install Python 3.11+ from <https://www.python.org/downloads/windows/>. During setup, enable the option to add Python to PATH.
3. Double-click `run.bat`. On first run it creates `.venv`, installs the dependencies, and copies `.env.example` to `.env` if needed.
4. Open <http://127.0.0.1:8787> in your browser.
5. To stop the server, return to the terminal window and press `Ctrl+C`.

If Windows cannot find `py`, reinstall Python and enable the Python launcher / PATH option. See [Commands and troubleshooting](docs/COMMANDS.md).

## Configure an AI provider

1. Stop NEXORA if it is running.
2. Open `.env` in Notepad. It is created from `.env.example` on first run.
3. Put provider credentials only in the appropriate local `.env` setting. Keep the key private and do not paste it into chat, issue reports, screenshots, frontend code, or source files.
4. Save `.env` and restart NEXORA.
5. In the dashboard, choose the provider and a model identifier supported by that provider.

Official provider dashboards and documentation:

- Gemini: <https://aistudio.google.com/app/apikey>
- OpenRouter: <https://openrouter.ai/keys>
- Groq: <https://console.groq.com/keys>
- Mistral: <https://console.mistral.ai/>
- NVIDIA NIM: <https://build.nvidia.com/>
- Cerebras: <https://cloud.cerebras.ai/>
- Cohere: <https://dashboard.cohere.com/api-keys>
- Hugging Face: <https://huggingface.co/settings/tokens>

Provider names, free tiers, model IDs, quotas, and endpoints can change. Verify them on the provider's official site. Never assume a service offers unlimited free usage.

## Optional local AI services

NEXORA can be configured to use OpenAI-compatible local endpoints. Example base URLs (adjust to your own service configuration):

| Service | Typical local base URL |
|---|---|
| Ollama | `http://127.0.0.1:11434/v1` |
| LM Studio | `http://127.0.0.1:1234/v1` |
| llama.cpp server | `http://127.0.0.1:8080/v1` |
| vLLM | `http://127.0.0.1:8000/v1` |
| LocalAI | `http://127.0.0.1:8081/v1` |
| Jan | `http://127.0.0.1:1337/v1` |
| LiteLLM proxy | `http://127.0.0.1:4000/v1` |

Some services require a model to be downloaded or loaded first. Local endpoint compatibility varies by model and server version.

## Optional FreeToken gateway

FreeToken is a separate project and is not bundled with NEXORA. Review its source and scripts before running it: <https://github.com/V-Groups-Foundations/freetoken>.

Typical setup (confirm the repository's current instructions first):

```powershell
git clone https://github.com/V-Groups-Foundations/freetoken.git
cd freetoken
npm install
npm run dev
```

Use its own UI to configure the gateway, then store any local gateway token in NEXORA's `.env`. A gateway does not generate unlimited provider keys or bypass provider terms, quotas, billing, or access controls.

## Build a Windows EXE

On a Windows PC with Python 3.11+ installed:

1. Extract/clone the repository.
2. Double-click `build_exe.bat` and allow it to install the build dependencies.
3. If the script succeeds, inspect `dist\NEXORA-Forge.exe` and test it on the target Windows machine.
4. Keep the local `.env` beside the EXE as instructed by the launcher; do not distribute that file.

The script is a build recipe, **not a prebuilt or verified executable**. A successful build is not guaranteed on every PC; antivirus policies, PyInstaller packaging, native dependencies, and Windows permissions can affect the result. Review [Commands and troubleshooting](docs/COMMANDS.md). This project has not been represented as tested on your computer.

## Current implementation and limitations

Implemented in this starter:

- Local FastAPI dashboard bound to `127.0.0.1:8787`
- AI chat requests through configured OpenAI-compatible endpoints
- Local `.env` provider configuration pattern
- Local file-upload storage
- Basic web-project scaffold generation
- API/resource catalog sync from a fixed set of public Markdown sources
- Saving MCP server configuration as local configuration data
- Windows launch and PyInstaller build scripts

Not implemented as a complete production feature in this version:

- MCP server process launching or real MCP tool execution
- Fully autonomous multi-file AI coding, build/test/debug/repair loops
- Full browser/computer-use agent with unrestricted click/type actions
- Video generation, Android SDK APK compilation or APK signing
- Google OAuth, multi-user accounts, hosted/cloud deployment, or production authentication
- Automated trading or real-money order execution

Do not interpret a saved MCP configuration, provider entry, or UI label as proof that the integration is operational. Treat generated code and external repository code as untrusted until reviewed and tested.

## Security essentials

- Never commit `.env`, API keys, passwords, tokens, personal files, or generated user uploads.
- `.gitignore` excludes `.env`, the virtual environment, Python cache, and runtime upload/project data. Review `git status` before every commit.
- Keep the server bound to loopback (`127.0.0.1`). Do not expose port `8787` or a local gateway port to the public internet without authentication, TLS, and a security review.
- Desktop automation can type, click, or otherwise affect your PC. Test in a disposable workspace and confirm high-impact actions manually.
- Review licenses and code before running any third-party GitHub repository or MCP server.

See [Security notes](docs/SECURITY.md).

## GitHub resources

See [Resource catalog and upstream projects](docs/RESOURCES.md) for dataset repositories, public APIs, MCP servers, agent skills, local AI runtimes, and the OpenSwissData endpoint.

## Tests

Run the basic smoke test from the project directory:

```powershell
py -3 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
python tests\smoke_test.py
```

These are smoke checks only; they do not validate all integrations or guarantee production readiness.

## License

The repository currently contains a `LICENSE` file. Review its terms and confirm it is appropriate for all source files before redistributing or accepting outside contributions.

## Contributing

1. Create a branch for your change.
2. Keep credentials and runtime data out of commits.
3. Run the smoke test and manually verify the changed feature.
4. Document any feature that is a placeholder or requires external setup.
5. Submit a pull request with a concise description and test results.
